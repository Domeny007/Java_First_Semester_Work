--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.5
-- Dumped by pg_dump version 9.6.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.reviews DROP CONSTRAINT writer_id_fk;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_user_right_fkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_country_id_fkey;
ALTER TABLE ONLY public.reviews_users_votes_bind DROP CONSTRAINT reviews_users_votes_bind_user_id_fkey;
ALTER TABLE ONLY public.reviews_users_votes_bind DROP CONSTRAINT reviews_users_votes_bind_review_id_fkey;
ALTER TABLE ONLY public.reviews DROP CONSTRAINT reviews_movie_id_fkey;
ALTER TABLE ONLY public.reviews DROP CONSTRAINT reviews_director_id_fkey;
ALTER TABLE ONLY public.reviews DROP CONSTRAINT reviews_actor_id_fkey;
ALTER TABLE ONLY public.movies_users_votes_bind DROP CONSTRAINT movies_users_votes_bind_user_id_fkey;
ALTER TABLE ONLY public.movies_users_votes_bind DROP CONSTRAINT movies_users_votes_bind_movie_id_fkey;
ALTER TABLE ONLY public.movies_genres_bind DROP CONSTRAINT movies_genres_bind_movie_id_fkey;
ALTER TABLE ONLY public.movies_genres_bind DROP CONSTRAINT movies_genres_bind_genre_id_fkey;
ALTER TABLE ONLY public.movies_directors_bind DROP CONSTRAINT movies_directors_bind_movie_id_fkey;
ALTER TABLE ONLY public.movies_directors_bind DROP CONSTRAINT movies_directors_bind_director_id_fkey;
ALTER TABLE ONLY public.movies_countries_bind DROP CONSTRAINT movies_countries_bind_movie_id_fkey;
ALTER TABLE ONLY public.movies_countries_bind DROP CONSTRAINT movies_countries_bind_country_id_fkey;
ALTER TABLE ONLY public.movies_actors_bind DROP CONSTRAINT movies_actors_bind_movie_id_fkey;
ALTER TABLE ONLY public.movies_actors_bind DROP CONSTRAINT movies_actors_bind_actor_id_fkey;
ALTER TABLE ONLY public.directors_users_votes_bind DROP CONSTRAINT directors_users_votes_bind_user_id_fkey;
ALTER TABLE ONLY public.directors_users_votes_bind DROP CONSTRAINT directors_users_votes_bind_director_id_fkey;
ALTER TABLE ONLY public.directors DROP CONSTRAINT directors_motherland_fkey;
ALTER TABLE ONLY public.actors_users_votes_bind DROP CONSTRAINT actors_users_votes_bind_user_id_fkey;
ALTER TABLE ONLY public.actors_users_votes_bind DROP CONSTRAINT actors_users_votes_bind_actor_id_fkey;
ALTER TABLE ONLY public.actors DROP CONSTRAINT actors_motherland_fkey;
DROP INDEX public.users_cookie_id_uindex;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pk;
ALTER TABLE ONLY public.rights DROP CONSTRAINT rights_pk;
ALTER TABLE ONLY public.reviews_users_votes_bind DROP CONSTRAINT reviews_users_votes_bind_pk;
ALTER TABLE ONLY public.reviews DROP CONSTRAINT reviews_pk;
ALTER TABLE ONLY public.movies_users_votes_bind DROP CONSTRAINT movies_users_votes_bind_pk;
ALTER TABLE ONLY public.movies DROP CONSTRAINT movies_pk;
ALTER TABLE ONLY public.movies_genres_bind DROP CONSTRAINT movies_genres_bind__pk;
ALTER TABLE ONLY public.movies_directors_bind DROP CONSTRAINT movies_directors_bind__pk;
ALTER TABLE ONLY public.movies_countries_bind DROP CONSTRAINT movies_countries_bind__pk;
ALTER TABLE ONLY public.movies_actors_bind DROP CONSTRAINT movies_actors_bind__pk;
ALTER TABLE ONLY public.genres DROP CONSTRAINT genre_pk;
ALTER TABLE ONLY public.directors_users_votes_bind DROP CONSTRAINT directors_users_votes_bind_pk;
ALTER TABLE ONLY public.directors DROP CONSTRAINT directors_pk;
ALTER TABLE ONLY public.countries DROP CONSTRAINT countries_pk;
ALTER TABLE ONLY public.actors_users_votes_bind DROP CONSTRAINT actors_users_votes_bind_pk;
ALTER TABLE ONLY public.actors DROP CONSTRAINT actors_pk;
ALTER TABLE public.users ALTER COLUMN user_id DROP DEFAULT;
ALTER TABLE public.rights ALTER COLUMN right_id DROP DEFAULT;
ALTER TABLE public.reviews ALTER COLUMN review_id DROP DEFAULT;
ALTER TABLE public.movies ALTER COLUMN movie_id DROP DEFAULT;
ALTER TABLE public.genres ALTER COLUMN genre_id DROP DEFAULT;
ALTER TABLE public.directors ALTER COLUMN director_id DROP DEFAULT;
ALTER TABLE public.countries ALTER COLUMN country_id DROP DEFAULT;
ALTER TABLE public.actors ALTER COLUMN actor_id DROP DEFAULT;
DROP SEQUENCE public.users_user_id_seq;
DROP TABLE public.users;
DROP SEQUENCE public.rights_right_id_seq;
DROP TABLE public.rights;
DROP TABLE public.reviews_users_votes_bind;
DROP SEQUENCE public.reviews_review_id_seq;
DROP TABLE public.movies_users_votes_bind;
DROP SEQUENCE public.movies_movie_id_seq;
DROP TABLE public.movies_genres_bind;
DROP TABLE public.movies_directors_bind;
DROP TABLE public.movies_countries_bind;
DROP TABLE public.movies_actors_bind;
DROP TABLE public.movies;
DROP SEQUENCE public.genres_genre_id_seq;
DROP TABLE public.directors_users_votes_bind;
DROP SEQUENCE public.directors_director_id_seq;
DROP SEQUENCE public.countries_country_id_seq;
DROP TABLE public.actors_users_votes_bind;
DROP SEQUENCE public.actors_actor_id_seq;
DROP FUNCTION public.getusermoviemark(integer, integer);
DROP FUNCTION public.getuserdirectormark(integer, integer);
DROP FUNCTION public.getuseractormark(integer, integer);
DROP FUNCTION public.getmoviereviews(integer);
DROP TABLE public.reviews;
DROP FUNCTION public.getmoviegenres(integer);
DROP TABLE public.genres;
DROP FUNCTION public.getmoviedirectors(integer);
DROP TABLE public.directors;
DROP FUNCTION public.getmoviecountries(integer);
DROP TABLE public.countries;
DROP FUNCTION public.getmovieactors(integer);
DROP TABLE public.actors;
DROP FUNCTION public.getcommonreviewmark(integer);
DROP FUNCTION public.getcommonmoviemark(integer);
DROP FUNCTION public.getcommondirectormark(integer);
DROP FUNCTION public.getcommonactormark(integer);
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: getcommonactormark(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION getcommonactormark(integer) RETURNS integer
    LANGUAGE sql
    AS $_$
    SELECT cast(round(cast(SUM(mark) AS DOUBLE PRECISION)/COUNT(user_id)) AS INTEGER)
    FROM actors_users_votes_bind
    WHERE actor_id = $1;
$_$;


ALTER FUNCTION public.getcommonactormark(integer) OWNER TO postgres;

--
-- Name: getcommondirectormark(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION getcommondirectormark(integer) RETURNS integer
    LANGUAGE sql
    AS $_$
    SELECT cast(round(cast(SUM(mark) AS DOUBLE PRECISION)/COUNT(user_id)) AS INTEGER)
    FROM directors_users_votes_bind
    WHERE director_id = $1;
$_$;


ALTER FUNCTION public.getcommondirectormark(integer) OWNER TO postgres;

--
-- Name: getcommonmoviemark(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION getcommonmoviemark(integer) RETURNS integer
    LANGUAGE sql
    AS $_$
    SELECT cast(round(cast(SUM(mark) AS DOUBLE PRECISION)/COUNT(user_id)) AS INTEGER)
    FROM movies_users_votes_bind
    WHERE movie_id = $1;
$_$;


ALTER FUNCTION public.getcommonmoviemark(integer) OWNER TO postgres;

--
-- Name: getcommonreviewmark(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION getcommonreviewmark(integer) RETURNS integer
    LANGUAGE sql
    AS $_$
    SELECT cast(round(cast(SUM(mark) AS DOUBLE PRECISION)/COUNT(user_id)) AS INTEGER)
    FROM reviews_users_votes_bind
    WHERE review_id = $1;
$_$;


ALTER FUNCTION public.getcommonreviewmark(integer) OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: actors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE actors (
    actor_id integer NOT NULL,
    name character varying(50) NOT NULL,
    surname character varying(50) NOT NULL,
    birthday date NOT NULL,
    motherland integer NOT NULL,
    photo text NOT NULL,
    mark integer DEFAULT 0,
    subscription text,
    CONSTRAINT actors_birthday_min CHECK (((date_part('year'::text, birthday) >= (1800)::double precision) AND (date_part('year'::text, birthday) <= date_part('year'::text, ('now'::text)::date)))),
    CONSTRAINT movies_mark_range CHECK (((mark >= 0) AND (mark <= 10)))
);


ALTER TABLE actors OWNER TO postgres;

--
-- Name: getmovieactors(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION getmovieactors(integer) RETURNS SETOF actors
    LANGUAGE sql
    AS $_$
    SELECT actors.actor_id,actors.name,actors.surname,actors.birthday,
        actors.motherland,actors.photo,actors.mark,actors.subscription
    FROM actors
    INNER JOIN movies_actors_bind ON actors.actor_id = movies_actors_bind.actor_id
    WHERE movies_actors_bind.movie_id = $1;
$_$;


ALTER FUNCTION public.getmovieactors(integer) OWNER TO postgres;

--
-- Name: countries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE countries (
    country_id integer NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE countries OWNER TO postgres;

--
-- Name: getmoviecountries(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION getmoviecountries(integer) RETURNS SETOF countries
    LANGUAGE sql
    AS $_$
    SELECT countries.country_id,countries.name
    FROM countries
    INNER JOIN movies_countries_bind ON countries.country_id = movies_countries_bind.country_id
    WHERE movies_countries_bind.movie_id = $1;
$_$;


ALTER FUNCTION public.getmoviecountries(integer) OWNER TO postgres;

--
-- Name: directors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE directors (
    director_id integer NOT NULL,
    name character varying(50) NOT NULL,
    surname character varying(50) NOT NULL,
    birthday date NOT NULL,
    motherland integer NOT NULL,
    photo text NOT NULL,
    mark integer DEFAULT 0,
    subscription text,
    CONSTRAINT directors_birthday_min CHECK (((date_part('year'::text, birthday) >= (1800)::double precision) AND (date_part('year'::text, birthday) <= date_part('year'::text, ('now'::text)::date)))),
    CONSTRAINT movies_mark_range CHECK (((mark >= 0) AND (mark <= 10)))
);


ALTER TABLE directors OWNER TO postgres;

--
-- Name: getmoviedirectors(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION getmoviedirectors(integer) RETURNS SETOF directors
    LANGUAGE sql
    AS $_$
    SELECT directors.director_id,directors.name,directors.surname,directors.birthday,
        directors.motherland,directors.photo,directors.mark,directors.subscription
    FROM directors
    INNER JOIN movies_directors_bind ON directors.director_id = movies_directors_bind.director_id
    WHERE movies_directors_bind.movie_id = $1;
$_$;


ALTER FUNCTION public.getmoviedirectors(integer) OWNER TO postgres;

--
-- Name: genres; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE genres (
    genre_id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE genres OWNER TO postgres;

--
-- Name: getmoviegenres(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION getmoviegenres(integer) RETURNS SETOF genres
    LANGUAGE sql
    AS $_$
    SELECT genres.genre_id,genres.name
    FROM genres
    INNER JOIN movies_genres_bind ON genres.genre_id = movies_genres_bind.genre_id
    WHERE movies_genres_bind.movie_id = $1;
$_$;


ALTER FUNCTION public.getmoviegenres(integer) OWNER TO postgres;

--
-- Name: reviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE reviews (
    review_id integer NOT NULL,
    title character varying(100) NOT NULL,
    content character varying(2000) NOT NULL,
    writer_id integer NOT NULL,
    movie_id integer,
    actor_id integer,
    director_id integer,
    mark integer DEFAULT 0 NOT NULL,
    CONSTRAINT checkonlyonecolumnnotnull CHECK ((((
CASE
    WHEN (movie_id IS NOT NULL) THEN 1
    ELSE 0
END +
CASE
    WHEN (actor_id IS NOT NULL) THEN 1
    ELSE 0
END) +
CASE
    WHEN (director_id IS NOT NULL) THEN 1
    ELSE 0
END) = 1)),
    CONSTRAINT review_mark_range CHECK (((mark >= 0) AND (mark <= 10)))
);


ALTER TABLE reviews OWNER TO postgres;

--
-- Name: getmoviereviews(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION getmoviereviews(integer) RETURNS SETOF reviews
    LANGUAGE sql
    AS $_$
    SELECT reviews.review_id,reviews.title,reviews.content,reviews.writer_id
    FROM reviews
    INNER JOIN movies_reviews_bind ON reviews.review_id = movies_reviews_bind.review_id
    WHERE movies_reviews_bind.movie_id = $1;
$_$;


ALTER FUNCTION public.getmoviereviews(integer) OWNER TO postgres;

--
-- Name: getuseractormark(integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION getuseractormark(integer, integer) RETURNS integer
    LANGUAGE sql
    AS $_$
    SELECT mark
    FROM actors_users_votes_bind
    WHERE  actor_id = $1 AND user_id = $2;
$_$;


ALTER FUNCTION public.getuseractormark(integer, integer) OWNER TO postgres;

--
-- Name: getuserdirectormark(integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION getuserdirectormark(integer, integer) RETURNS integer
    LANGUAGE sql
    AS $_$
    SELECT mark
    FROM directors_users_votes_bind
    WHERE  director_id = $1 AND user_id = $2;
$_$;


ALTER FUNCTION public.getuserdirectormark(integer, integer) OWNER TO postgres;

--
-- Name: getusermoviemark(integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION getusermoviemark(integer, integer) RETURNS integer
    LANGUAGE sql
    AS $_$
    SELECT mark
    FROM movies_users_votes_bind
    WHERE  movie_id = $1 AND user_id = $2;
$_$;


ALTER FUNCTION public.getusermoviemark(integer, integer) OWNER TO postgres;

--
-- Name: actors_actor_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE actors_actor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE actors_actor_id_seq OWNER TO postgres;

--
-- Name: actors_actor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE actors_actor_id_seq OWNED BY actors.actor_id;


--
-- Name: actors_users_votes_bind; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE actors_users_votes_bind (
    actor_id integer NOT NULL,
    user_id integer NOT NULL,
    mark integer NOT NULL,
    CONSTRAINT actors_mark_range CHECK (((mark >= 0) AND (mark <= 10)))
);


ALTER TABLE actors_users_votes_bind OWNER TO postgres;

--
-- Name: countries_country_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE countries_country_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE countries_country_id_seq OWNER TO postgres;

--
-- Name: countries_country_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE countries_country_id_seq OWNED BY countries.country_id;


--
-- Name: directors_director_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE directors_director_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE directors_director_id_seq OWNER TO postgres;

--
-- Name: directors_director_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE directors_director_id_seq OWNED BY directors.director_id;


--
-- Name: directors_users_votes_bind; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE directors_users_votes_bind (
    director_id integer NOT NULL,
    user_id integer NOT NULL,
    mark integer NOT NULL,
    CONSTRAINT directors_mark_range CHECK (((mark >= 0) AND (mark <= 10)))
);


ALTER TABLE directors_users_votes_bind OWNER TO postgres;

--
-- Name: genres_genre_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE genres_genre_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE genres_genre_id_seq OWNER TO postgres;

--
-- Name: genres_genre_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE genres_genre_id_seq OWNED BY genres.genre_id;


--
-- Name: movies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE movies (
    movie_id integer NOT NULL,
    name character varying(100) NOT NULL,
    subscription text NOT NULL,
    year date NOT NULL,
    budget integer NOT NULL,
    money integer DEFAULT 0 NOT NULL,
    mark integer DEFAULT 0,
    photo text NOT NULL,
    CONSTRAINT movies_budget_limit CHECK ((budget > 0)),
    CONSTRAINT movies_mark_range CHECK (((mark >= 0) AND (mark <= 10))),
    CONSTRAINT movies_year_check CHECK (((date_part('year'::text, year) >= (1900)::double precision) AND (date_part('year'::text, year) <= date_part('year'::text, ('now'::text)::date))))
);


ALTER TABLE movies OWNER TO postgres;

--
-- Name: movies_actors_bind; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE movies_actors_bind (
    actor_id integer NOT NULL,
    movie_id integer NOT NULL
);


ALTER TABLE movies_actors_bind OWNER TO postgres;

--
-- Name: movies_countries_bind; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE movies_countries_bind (
    country_id integer NOT NULL,
    movie_id integer NOT NULL
);


ALTER TABLE movies_countries_bind OWNER TO postgres;

--
-- Name: movies_directors_bind; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE movies_directors_bind (
    director_id integer NOT NULL,
    movie_id integer NOT NULL
);


ALTER TABLE movies_directors_bind OWNER TO postgres;

--
-- Name: movies_genres_bind; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE movies_genres_bind (
    genre_id integer NOT NULL,
    movie_id integer NOT NULL
);


ALTER TABLE movies_genres_bind OWNER TO postgres;

--
-- Name: movies_movie_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE movies_movie_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE movies_movie_id_seq OWNER TO postgres;

--
-- Name: movies_movie_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE movies_movie_id_seq OWNED BY movies.movie_id;


--
-- Name: movies_users_votes_bind; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE movies_users_votes_bind (
    movie_id integer NOT NULL,
    user_id integer NOT NULL,
    mark integer NOT NULL,
    CONSTRAINT mark_range CHECK (((mark >= 0) AND (mark <= 10)))
);


ALTER TABLE movies_users_votes_bind OWNER TO postgres;

--
-- Name: reviews_review_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE reviews_review_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE reviews_review_id_seq OWNER TO postgres;

--
-- Name: reviews_review_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE reviews_review_id_seq OWNED BY reviews.review_id;


--
-- Name: reviews_users_votes_bind; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE reviews_users_votes_bind (
    review_id integer NOT NULL,
    user_id integer NOT NULL,
    mark integer NOT NULL,
    CONSTRAINT reviews_mark_range CHECK (((mark >= 0) AND (mark <= 10)))
);


ALTER TABLE reviews_users_votes_bind OWNER TO postgres;

--
-- Name: rights; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE rights (
    right_id integer NOT NULL,
    right_name character varying(30)
);


ALTER TABLE rights OWNER TO postgres;

--
-- Name: rights_right_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE rights_right_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE rights_right_id_seq OWNER TO postgres;

--
-- Name: rights_right_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE rights_right_id_seq OWNED BY rights.right_id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE users (
    user_id integer NOT NULL,
    email character varying(100) NOT NULL,
    password character varying(100) NOT NULL,
    username character varying(100) NOT NULL,
    mark integer DEFAULT 0,
    country_id integer NOT NULL,
    gender character varying(10) NOT NULL,
    user_right integer DEFAULT 2 NOT NULL,
    cookie_id text NOT NULL,
    CONSTRAINT movies_mark_range CHECK (((mark >= 0) AND (mark <= 10))),
    CONSTRAINT users_gender_range CHECK (((gender)::text = ANY ((ARRAY['мужской'::character varying, 'женский'::character varying])::text[])))
);


ALTER TABLE users OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE users_user_id_seq OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE users_user_id_seq OWNED BY users.user_id;


--
-- Name: actors actor_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY actors ALTER COLUMN actor_id SET DEFAULT nextval('actors_actor_id_seq'::regclass);


--
-- Name: countries country_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY countries ALTER COLUMN country_id SET DEFAULT nextval('countries_country_id_seq'::regclass);


--
-- Name: directors director_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY directors ALTER COLUMN director_id SET DEFAULT nextval('directors_director_id_seq'::regclass);


--
-- Name: genres genre_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY genres ALTER COLUMN genre_id SET DEFAULT nextval('genres_genre_id_seq'::regclass);


--
-- Name: movies movie_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY movies ALTER COLUMN movie_id SET DEFAULT nextval('movies_movie_id_seq'::regclass);


--
-- Name: reviews review_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY reviews ALTER COLUMN review_id SET DEFAULT nextval('reviews_review_id_seq'::regclass);


--
-- Name: rights right_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY rights ALTER COLUMN right_id SET DEFAULT nextval('rights_right_id_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users ALTER COLUMN user_id SET DEFAULT nextval('users_user_id_seq'::regclass);


--
-- Data for Name: actors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY actors (actor_id, name, surname, birthday, motherland, photo, mark, subscription) FROM stdin;
\.
COPY actors (actor_id, name, surname, birthday, motherland, photo, mark, subscription) FROM '$$PATH$$/2303.dat';

--
-- Name: actors_actor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('actors_actor_id_seq', 17, true);


--
-- Data for Name: actors_users_votes_bind; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY actors_users_votes_bind (actor_id, user_id, mark) FROM stdin;
\.
COPY actors_users_votes_bind (actor_id, user_id, mark) FROM '$$PATH$$/2315.dat';

--
-- Data for Name: countries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY countries (country_id, name) FROM stdin;
\.
COPY countries (country_id, name) FROM '$$PATH$$/2299.dat';

--
-- Name: countries_country_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('countries_country_id_seq', 6, true);


--
-- Data for Name: directors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY directors (director_id, name, surname, birthday, motherland, photo, mark, subscription) FROM stdin;
\.
COPY directors (director_id, name, surname, birthday, motherland, photo, mark, subscription) FROM '$$PATH$$/2305.dat';

--
-- Name: directors_director_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('directors_director_id_seq', 16, true);


--
-- Data for Name: directors_users_votes_bind; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY directors_users_votes_bind (director_id, user_id, mark) FROM stdin;
\.
COPY directors_users_votes_bind (director_id, user_id, mark) FROM '$$PATH$$/2316.dat';

--
-- Data for Name: genres; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY genres (genre_id, name) FROM stdin;
\.
COPY genres (genre_id, name) FROM '$$PATH$$/2301.dat';

--
-- Name: genres_genre_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('genres_genre_id_seq', 7, true);


--
-- Data for Name: movies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY movies (movie_id, name, subscription, year, budget, money, mark, photo) FROM stdin;
\.
COPY movies (movie_id, name, subscription, year, budget, money, mark, photo) FROM '$$PATH$$/2297.dat';

--
-- Data for Name: movies_actors_bind; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY movies_actors_bind (actor_id, movie_id) FROM stdin;
\.
COPY movies_actors_bind (actor_id, movie_id) FROM '$$PATH$$/2308.dat';

--
-- Data for Name: movies_countries_bind; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY movies_countries_bind (country_id, movie_id) FROM stdin;
\.
COPY movies_countries_bind (country_id, movie_id) FROM '$$PATH$$/2307.dat';

--
-- Data for Name: movies_directors_bind; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY movies_directors_bind (director_id, movie_id) FROM stdin;
\.
COPY movies_directors_bind (director_id, movie_id) FROM '$$PATH$$/2309.dat';

--
-- Data for Name: movies_genres_bind; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY movies_genres_bind (genre_id, movie_id) FROM stdin;
\.
COPY movies_genres_bind (genre_id, movie_id) FROM '$$PATH$$/2306.dat';

--
-- Name: movies_movie_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('movies_movie_id_seq', 22, true);


--
-- Data for Name: movies_users_votes_bind; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY movies_users_votes_bind (movie_id, user_id, mark) FROM stdin;
\.
COPY movies_users_votes_bind (movie_id, user_id, mark) FROM '$$PATH$$/2314.dat';

--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY reviews (review_id, title, content, writer_id, movie_id, actor_id, director_id, mark) FROM stdin;
\.
COPY reviews (review_id, title, content, writer_id, movie_id, actor_id, director_id, mark) FROM '$$PATH$$/2313.dat';

--
-- Name: reviews_review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('reviews_review_id_seq', 17, true);


--
-- Data for Name: reviews_users_votes_bind; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY reviews_users_votes_bind (review_id, user_id, mark) FROM stdin;
\.
COPY reviews_users_votes_bind (review_id, user_id, mark) FROM '$$PATH$$/2319.dat';

--
-- Data for Name: rights; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY rights (right_id, right_name) FROM stdin;
\.
COPY rights (right_id, right_name) FROM '$$PATH$$/2318.dat';

--
-- Name: rights_right_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('rights_right_id_seq', 2, true);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY users (user_id, email, password, username, mark, country_id, gender, user_right, cookie_id) FROM stdin;
\.
COPY users (user_id, email, password, username, mark, country_id, gender, user_right, cookie_id) FROM '$$PATH$$/2311.dat';

--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('users_user_id_seq', 20, true);


--
-- Name: actors actors_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY actors
    ADD CONSTRAINT actors_pk PRIMARY KEY (actor_id);


--
-- Name: actors_users_votes_bind actors_users_votes_bind_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY actors_users_votes_bind
    ADD CONSTRAINT actors_users_votes_bind_pk PRIMARY KEY (actor_id, user_id);


--
-- Name: countries countries_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY countries
    ADD CONSTRAINT countries_pk PRIMARY KEY (country_id);


--
-- Name: directors directors_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY directors
    ADD CONSTRAINT directors_pk PRIMARY KEY (director_id);


--
-- Name: directors_users_votes_bind directors_users_votes_bind_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY directors_users_votes_bind
    ADD CONSTRAINT directors_users_votes_bind_pk PRIMARY KEY (director_id, user_id);


--
-- Name: genres genre_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY genres
    ADD CONSTRAINT genre_pk PRIMARY KEY (genre_id);


--
-- Name: movies_actors_bind movies_actors_bind__pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY movies_actors_bind
    ADD CONSTRAINT movies_actors_bind__pk PRIMARY KEY (movie_id, actor_id);


--
-- Name: movies_countries_bind movies_countries_bind__pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY movies_countries_bind
    ADD CONSTRAINT movies_countries_bind__pk PRIMARY KEY (movie_id, country_id);


--
-- Name: movies_directors_bind movies_directors_bind__pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY movies_directors_bind
    ADD CONSTRAINT movies_directors_bind__pk PRIMARY KEY (movie_id, director_id);


--
-- Name: movies_genres_bind movies_genres_bind__pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY movies_genres_bind
    ADD CONSTRAINT movies_genres_bind__pk PRIMARY KEY (movie_id, genre_id);


--
-- Name: movies movies_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY movies
    ADD CONSTRAINT movies_pk PRIMARY KEY (movie_id);


--
-- Name: movies_users_votes_bind movies_users_votes_bind_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY movies_users_votes_bind
    ADD CONSTRAINT movies_users_votes_bind_pk PRIMARY KEY (movie_id, user_id);


--
-- Name: reviews reviews_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY reviews
    ADD CONSTRAINT reviews_pk PRIMARY KEY (review_id);


--
-- Name: reviews_users_votes_bind reviews_users_votes_bind_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY reviews_users_votes_bind
    ADD CONSTRAINT reviews_users_votes_bind_pk PRIMARY KEY (review_id, user_id);


--
-- Name: rights rights_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY rights
    ADD CONSTRAINT rights_pk PRIMARY KEY (right_id);


--
-- Name: users users_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pk PRIMARY KEY (user_id);


--
-- Name: users_cookie_id_uindex; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_cookie_id_uindex ON users USING btree (cookie_id);


--
-- Name: actors actors_motherland_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY actors
    ADD CONSTRAINT actors_motherland_fkey FOREIGN KEY (motherland) REFERENCES countries(country_id);


--
-- Name: actors_users_votes_bind actors_users_votes_bind_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY actors_users_votes_bind
    ADD CONSTRAINT actors_users_votes_bind_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: actors_users_votes_bind actors_users_votes_bind_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY actors_users_votes_bind
    ADD CONSTRAINT actors_users_votes_bind_user_id_fkey FOREIGN KEY (user_id) REFERENCES users(user_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: directors directors_motherland_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY directors
    ADD CONSTRAINT directors_motherland_fkey FOREIGN KEY (motherland) REFERENCES countries(country_id);


--
-- Name: directors_users_votes_bind directors_users_votes_bind_director_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY directors_users_votes_bind
    ADD CONSTRAINT directors_users_votes_bind_director_id_fkey FOREIGN KEY (director_id) REFERENCES directors(director_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: directors_users_votes_bind directors_users_votes_bind_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY directors_users_votes_bind
    ADD CONSTRAINT directors_users_votes_bind_user_id_fkey FOREIGN KEY (user_id) REFERENCES users(user_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: movies_actors_bind movies_actors_bind_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY movies_actors_bind
    ADD CONSTRAINT movies_actors_bind_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES actors(actor_id);


--
-- Name: movies_actors_bind movies_actors_bind_movie_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY movies_actors_bind
    ADD CONSTRAINT movies_actors_bind_movie_id_fkey FOREIGN KEY (movie_id) REFERENCES movies(movie_id);


--
-- Name: movies_countries_bind movies_countries_bind_country_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY movies_countries_bind
    ADD CONSTRAINT movies_countries_bind_country_id_fkey FOREIGN KEY (country_id) REFERENCES countries(country_id);


--
-- Name: movies_countries_bind movies_countries_bind_movie_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY movies_countries_bind
    ADD CONSTRAINT movies_countries_bind_movie_id_fkey FOREIGN KEY (movie_id) REFERENCES movies(movie_id);


--
-- Name: movies_directors_bind movies_directors_bind_director_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY movies_directors_bind
    ADD CONSTRAINT movies_directors_bind_director_id_fkey FOREIGN KEY (director_id) REFERENCES directors(director_id);


--
-- Name: movies_directors_bind movies_directors_bind_movie_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY movies_directors_bind
    ADD CONSTRAINT movies_directors_bind_movie_id_fkey FOREIGN KEY (movie_id) REFERENCES movies(movie_id);


--
-- Name: movies_genres_bind movies_genres_bind_genre_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY movies_genres_bind
    ADD CONSTRAINT movies_genres_bind_genre_id_fkey FOREIGN KEY (genre_id) REFERENCES genres(genre_id);


--
-- Name: movies_genres_bind movies_genres_bind_movie_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY movies_genres_bind
    ADD CONSTRAINT movies_genres_bind_movie_id_fkey FOREIGN KEY (movie_id) REFERENCES movies(movie_id);


--
-- Name: movies_users_votes_bind movies_users_votes_bind_movie_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY movies_users_votes_bind
    ADD CONSTRAINT movies_users_votes_bind_movie_id_fkey FOREIGN KEY (movie_id) REFERENCES movies(movie_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: movies_users_votes_bind movies_users_votes_bind_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY movies_users_votes_bind
    ADD CONSTRAINT movies_users_votes_bind_user_id_fkey FOREIGN KEY (user_id) REFERENCES users(user_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: reviews reviews_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY reviews
    ADD CONSTRAINT reviews_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES actors(actor_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: reviews reviews_director_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY reviews
    ADD CONSTRAINT reviews_director_id_fkey FOREIGN KEY (director_id) REFERENCES directors(director_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: reviews reviews_movie_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY reviews
    ADD CONSTRAINT reviews_movie_id_fkey FOREIGN KEY (movie_id) REFERENCES movies(movie_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: reviews_users_votes_bind reviews_users_votes_bind_review_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY reviews_users_votes_bind
    ADD CONSTRAINT reviews_users_votes_bind_review_id_fkey FOREIGN KEY (review_id) REFERENCES reviews(review_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: reviews_users_votes_bind reviews_users_votes_bind_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY reviews_users_votes_bind
    ADD CONSTRAINT reviews_users_votes_bind_user_id_fkey FOREIGN KEY (user_id) REFERENCES users(user_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_country_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_country_id_fkey FOREIGN KEY (country_id) REFERENCES countries(country_id);


--
-- Name: users users_user_right_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_user_right_fkey FOREIGN KEY (user_right) REFERENCES rights(right_id);


--
-- Name: reviews writer_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY reviews
    ADD CONSTRAINT writer_id_fk FOREIGN KEY (writer_id) REFERENCES users(user_id) ON UPDATE CASCADE;


--
-- PostgreSQL database dump complete
--

