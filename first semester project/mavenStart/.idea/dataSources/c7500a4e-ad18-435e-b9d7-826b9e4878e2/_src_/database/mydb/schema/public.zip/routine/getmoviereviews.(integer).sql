create function getmoviereviews(integer) returns SETOF reviews
LANGUAGE SQL
AS $$
SELECT reviews.review_id,reviews.title,reviews.content,reviews.writer_id
    FROM reviews
    INNER JOIN movies_reviews_bind ON reviews.review_id = movies_reviews_bind.review_id
    WHERE movies_reviews_bind.movie_id = $1;
$$;
