create function getcommondirectormark(integer) returns integer
LANGUAGE SQL
AS $$
SELECT cast(round(cast(SUM(mark) AS DOUBLE PRECISION)/COUNT(user_id)) AS INTEGER)
    FROM directors_users_votes_bind
    WHERE director_id = $1;
$$;
