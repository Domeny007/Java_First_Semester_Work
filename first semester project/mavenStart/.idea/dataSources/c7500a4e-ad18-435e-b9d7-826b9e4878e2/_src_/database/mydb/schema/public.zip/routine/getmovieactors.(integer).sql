create function getmovieactors(integer) returns SETOF actors
LANGUAGE SQL
AS $$
SELECT actors.actor_id,actors.name,actors.surname,actors.birthday,
        actors.motherland,actors.photo,actors.mark,actors.subscription
    FROM actors
    INNER JOIN movies_actors_bind ON actors.actor_id = movies_actors_bind.actor_id
    WHERE movies_actors_bind.movie_id = $1;
$$;
