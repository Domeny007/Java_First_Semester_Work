create function getcommonreviewmark(integer) returns integer
LANGUAGE SQL
AS $$
SELECT cast(round(cast(SUM(mark) AS DOUBLE PRECISION)/COUNT(user_id)) AS INTEGER)
    FROM reviews_users_votes_bind
    WHERE review_id = $1;
$$;
